/*********************************************************************************
* WEB322 – Assignment 04
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students. *
* Name: PANCHAL KHYATI Student ID: 132297169 Date: JULY 7,2017 *
* Online (Heroku) Link: https://sleepy-sierra-61412.herokuapp.com/ 
* ********************************************************************************/
var express = require("express");
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');
var app = express();
var path = require("path");
var dataService = require("./data-service.js");

var HTTP_PORT = process.env.PORT || 8080;
app.use(express.static('public'));

app.use(bodyParser.urlencoded({ extended: true }));
app.engine(".hbs", exphbs({
    extname: ".hbs", defaultLayout: 'layout',
    helpers: {
        equal: function (lvalue, rvalue, options) {
            if (arguments.length < 3)
                throw new Error("Handlebars Helper equal needs 2 parameters");
            if (lvalue != rvalue) {
                return options.inverse(this);
            } else {
                return options.fn(this);
            }
        }
    }
}));
app.set("view engine", ".hbs");
// call this function after the http server starts listening for requests
function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}

// setup a 'route' to listen on the default url path (http://localhost)
app.get("/", function (req, res) {

    //res.sendFile(path.join(__dirname, "/views/home.html"));
    res.render("home");
});

// setup another route to listen on /about
app.get("/about", function (req, res) {

    //res.sendFile(path.join(__dirname, "/views/about.html"));
    res.render("about");
});

dataService.initialize().then(() => {
    app.listen(HTTP_PORT, onHttpStart);
}).catch((err) => {
    console.log(err);
});

app.get("/employees", (req, res) => {
    if (req.query.status == "Full Time" || req.query.status == "Part Time") {
        var s = req.query.status;
        dataService.getEmployeesByStatus(s).then((data) => {
            res.render("employeeList", { data: data, title: "Employees" });
            //res.json(data);
        }).catch(() => {
            res.render("employeeList", { data: {}, title: "Employees" });
            //res.json({ message: "no results returned" });
        });
    }
    else if (req.query.manager) {
        var manag = req.query.manager;
        dataService.getEmployeesByManager(manag).then((data) => {
            res.render("employeeList", { data: data, title: "Employees" });
            //res.json(data);
        }).catch(() => {
            res.render("employeeList", { data: {}, title: "Employees" });
            //res.json({ message: "no results returned" });
        });
    }
    else if (req.query.department) {
        var depart = req.query.department;

        dataService.getEmployeesByDepartment(depart).then((data) => {
            res.render("employeeList", { data: data, title: "Employees" });
            //res.json(data);
        }).catch(() => {
            res.render("employeeList", { data: {}, title: "Employees" });
            //res.json({ message: "no results returned 11" });
        });
    }
    else {
        dataService.getAllEmployees().then((data) => {
            // res.json(data);
            res.render("employeeList", { data: data, title: "Employees" });
        }).catch(() => {
            //res.json({ message: "no results returned" });
            res.render("employeeList", { data: {}, title: "Employees" });
        });
    }

});

app.get("/employee/:empNum", (req, res) => {
    // initialize an empty object to store the values
    let viewData = {};
    dataService.getEmployeeByNum(req.params.empNum).then((data) => {
        viewData.data = data; //store employee data in the "viewData" object as "data"
    }).catch(() => {
        viewData.data = null; // set employee to null if there was an error
    }).then(dataService.getDepartments).then((data) => {
        viewData.departments = data; // store department data in the "viewData" object as "departments"
                                     // loop through viewData.departments and once we have found the departmentId that matches
                                     // the employee's "department" value, add a "selected" property to the matching
                                     // viewData.departments object
        for (let i = 0; i < viewData.departments.length; i++) {
            if (viewData.departments[i].departmentId == viewData.data[0].department) {
                viewData.departments[i].selected = true;
            }
        }
        // if not add department set Selected to false and promto a message to user, message like "Please Choose Department" in html.
        if (viewData.departments[viewData.departments.length-1].departmentId != viewData.data[0].department) {
            viewData.departments.Selected = false;
        }
    }).catch(() => {
        viewData.departments = []; // set departments to empty if there was an error
    }).then(() => {
        if (viewData.data == null){ // if no employee - return an error
            res.status(404).send("Employee Not Found!!!");
        } else {
            res.render("employee", { viewData: viewData }); // render the "employee" view
        }
    });
});

app.get("/managers", (req, res) => {
    dataService.getManagers().then((data) => {
        //res.json(data);
        res.render("employeeList", { data: data, title: "Employees (Managers)" });
    }).catch(() => {
        //res.json({ message: "no results returned" });
        res.render("employeeList", { data: {}, title: "Employees (Managers)" });
    });

});

app.get("/departments", (req, res) => {
    dataService.getDepartments().then((data) => {
        //res.json(data);
        res.render("departmentList", { data: data, title: "Departments" });
    }).catch(() => {
        //res.json({ message: "no results returned" });
        res.render("departmentList", { data: {}, title: "Departments" });
    });
});

app.get("/employees/add", (req, res) => {
    dataService.getDepartments().then((data) => {
        res.render("addEmployee",{departments: data});
    }).catch((err) => {
        res.render("addEmployee", {departments: []});
    });

});

app.post("/employees/add", (req, res) => {
    dataService.addEmployee(req.body).then((data) => {
        res.redirect("/employees");
    });
});


app.get("/departments/add", (req, res) => {
    dataService.getDepartments().then((data) => {
        res.render("addDepartment",{departments: data});
    }).catch((err) => {
        res.render("addDepartment", {departments: []});
    });

});

app.post("/departments/add", (req, res) => {
    dataService.addDepartment(req.body).then((data) => {
        res.redirect("/departments");
    });
});

app.post("/employee/update", (req, res) => {
    console.log(req.body);
    dataService.updateEmployee(req.body).then((data) => {
        res.redirect("/employees");
    });
});
app.post("/department/update", (req, res) => {
    console.log(req.body);
    dataService.updateDepartment(req.body).then((data) => {
        res.redirect("/departments");
    });
});
app.get("/employee/delete/:empNum", (req, res) => {
    dataService.deleteEmployeeByNum(req.params.empNum).then((data) => {
        res.redirect("/employees");
    }).catch((err) => {
        res.status(500).send("Unable to Remove Employee / Employee not found");
    });
});
app.use((req, res) => {
    res.status(404).send("Page Not Found");
});

app.listen(HTTP_PORT, onHttpStart);         