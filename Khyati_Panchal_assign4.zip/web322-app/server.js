/*********************************************************************************
* WEB322 – Assignment 03
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: KHYATI PANCHAL Student ID: 132297169 Date: 2017-06-23
*
* Online (Heroku) Link: https://sleepy-sierra-61412.herokuapp.com/
********************************************************************************/
var express = require("express");
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');
var app = express();
var dataService = require("./data-service.js");
var HTTP_PORT = process.env.PORT || 3000;
app.use(express.static('public'));
var path = require("path");

app.use(bodyParser.urlencoded({ extended: true }));

app.engine(".hbs", exphbs({
  extname: ".hbs",
  defaultLayout: 'layout',
  helpers: {
    equal: function (lvalue, rvalue, options) {
      if (arguments.length < 3)
        throw new Error("Handlebars Helper equal needs 2 parameters");
      if (lvalue != rvalue) {
        return options.inverse(this);
      }
      else {
        return options.fn(this);
      }
    }
  }
}));

app.set("view engine", ".hbs");

function onHttpStart() {
  console.log("Express http server listening on: " + HTTP_PORT);
}

app.get("/", function (req, res) {
  //res.sendFile(path.join(__dirname + "/views/home.html"));
  res.render("home");
});

app.get("/about", function (req, res) {
  //res.sendFile(path.join(__dirname + "/views/about.html"));
  res.render("about");
});

app.get("/employees", (req, res) => {
  if (req.query.status == 'Full Time' || req.query.status == 'Part Time') {
    dataService.getEmployeesByStatus(req.query.status).then((data) => {
      //res.json(data);
      res.render("employeeList", { data: data, title: "Employees" });
    }).catch(() => {
      //res.json({message: 'No result returned'});
      res.render("employeeList", { data: {}, title: "Employees" });
    });
  }
  else if (req.query.manager) {
    dataService.getEmployeesByManager(req.query.manager).then((data) => {
      //res.json(data);
      res.render("employeeList", { data: data, title: "Employees" });
    }).catch(() => {
      //res.json({message: 'No result returned'});
      res.render("employeeList", { data: {}, title: "Employees" });
    });
  }
  else if (req.query.department) {
    dataService.getEmployeesByDepartment(req.query.department).then((data) => {
      //res.json(data);
      res.render("employeeList", { data: data, title: "Employees" });
    }).catch(() => {
      //res.json({message: 'No data returned'});
      res.render("employeeList", { data: {}, title: "Employees" });
    });
  }
  else {
    dataService.getAllEmployees().then((data) => {
      res.render("employeeList", { data: data, title: "Employees" });
      //res.json(data);
    }).catch(() => {
      res.render("employeeList", { data: {}, title: "Employees" });
      //res.json({ message: 'No data returned' });
    });
  }
});

app.get("/employee/:empNum", (req, res) => {
  dataService.getEmployeeByNum(req.params.empNum).then((data) => {
    console.log(data);
    res.render("employee", { data: data, title: "Employees" });
  }).catch(() => {
    res.json({ message: "No result returned!" });
  });
});

app.get("/managers", (req, res) => {
  dataService.getManagers().then((data) => {
    res.render("employeeList", { data: data, title: "Employees (Managers)" });
    //res.json(data);
  }).catch(() => {
    res.render("employeeList", { data: {}, title: "Employees (Managers)" });
    //res.json({ message: 'No data returned' });
  });
});



app.get("/departments", (req, res) => {
  dataService.getDepartments().then((data) => {
    res.render("departmentList", { data: data, title: "Departments" });
    //res.json(data);
  }).catch(() => {
    res.render("departmentList", { data: {}, title: "Departments" });
    //res.json({ message: 'No data returned' });
  });
});

app.get("/employees/add", (req, res) => {
  res.render("addEmployee");
});

app.post("/employees/add", (req, res) => {
  dataService.addEmployee(req.body).then((data) => {
    res.redirect("/employees");
  });
});
app.post("/employee/update", (req, res) => {
  dataService.updateEmployee(req.body).then((data) => {
    res.redirect("/employees");
  });
});

dataService.initialize().then(() => {
  app.listen(HTTP_PORT, onHttpStart);
}).catch(() => {
  console.log('No data returned');
});

//Page Not found
app.use((req, res) => {
  res.status(404).send("Page Not Found");
});