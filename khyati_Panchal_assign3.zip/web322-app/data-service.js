const fs = require('fs');
var employees = [];
var departments = [];
module.exports.initialize = function()
{
    return new Promise( (resolve, reject) =>
    {      
            fs.readFile('./data/employees.json', (err, data) => 
            {
                if (err) 
                {
                    reject("Not able to read file");
                }
                else{
                    employees = JSON.parse(data);
                    fs.readFile('./data/departments.json', (err, data) =>{
                if (err) 
                {
                    reject("not able to read file");
                }
                else
                {
                    departments = JSON.parse(data);
                    resolve(employees);
                    resolve(departments);
                }         
             });
        }
    });
    });
};
module.exports.getAllEmployees = () =>
{
    return new Promise( (resolve, reject) =>
    {        
        if(employees.length > 0){
            resolve(employees); 
        }
        else
            reject("no results returned");
    });

};
module.exports.getEmployeesByStatus = (status) =>{
    return new Promise( (resolve, reject) =>
    {
        if(employees.length > 0){
        var j;
        var employeesByStatus = [];
        for(j = 0; j < employees.length; j++)
        {
            if(employees[j].status == status)
            {
                employeesByStatus.push(employees[j]);
                j++;
            }
        }         
        if(employeesByStatus.length > 0)
        {
             resolve(employeesByStatus);
        }
        }
        else
        { 
            reject("no results returned");
        }
    });
};
	module.exports.getEmployeesByDepartment = (department) =>
	{
	    return new Promise( (resolve, reject) =>
	{
        var j;
	var employeesByDept = [];
	for(j = 0; j < employees.length; j++)
	{
	    if(employees[j].department == department)
	    {
	        employeesByDept.push(employees[j]);
	        j++;
	    }
	}
	
	if(employeesByDept.length > 0)
    {
         resolve(employeesByDept);
    }
	else
    {
         reject("no results returned");
    }
	});
	};
	 
	module.exports.getEmployeesByManager = (manager) =>
	{
	    return new Promise( (resolve, reject) =>
	{
	var j;
    var empByManager = [];
	for(j = 0; j < employees.length; j++)
	{
	    if(employees[j].employeeManagerNum == manager)
	    {
	        empByManager.push(employees[j]);
	        j++;
	    }
	}	 
		
	if(empByManager.length > 0)
    {
         resolve(empByManager);
    }
    else
    {
         reject("no results returned");
    }
	});
	}
	
	 
	module.exports.getEmployeeByNum = (num) =>
	{
	    return new Promise( (resolve, reject) =>
	{
        var j;
	var employeesByNum = [];
	for(j = 0; j < employees.length; j++)
	{
	    if(employees[j].employeeNum == num)
	    {
	        employeesByNum.push(employees[j]);
	        j++;
	    }
	}
	if(employeesByNum.length > 0)
    {
         resolve(employeesByNum);
    }
    else
    {
         reject("no results returned");
    }
	});
	}
	
	 
	module.exports.getManagers = () =>
	{
	    return new Promise( (resolve, reject) =>{
	    var managers = [];
        var j;
	    for(j = 0; j < employees.length; j++)
	    {
	        if(employees[j].isManager)
	        {
	            getManagers.push(employees[j]);
	            j++;
	        }
	    }
        if(getManagers.length > 0)
        {
            resolve(managers);
        }
	else
    {
         reject("no results returned");
    }
	});
	};
	
	module.exports.getDepartments = () =>{
	return new Promise( (resolve, reject) =>{
	
	
	if(departments.length > 0)
    {
	    resolve(departments); 
    }
	else
    {
	    reject("no results returned");
    }
	});
	};
