/*********************************************************************************
* WEB322 – Assignment 03
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: KHYATI PANCHAL Student ID: 132297169 Date: 2017-06-10
*
* Online (Heroku) Link: __https://git.heroku.com/sleepy-sierra-61412.git__
********************************************************************************/
var express = require("express");
var app = express();
var dataService = require("./data-service.js");
var HTTP_PORT = process.env.PORT || 3000;
app.use(express.static('public'));
var path = require("path")

function onHttpStart()
{
  console.log("Express http server listening on: " + HTTP_PORT);
}

app.get("/", function(req,res)
{
  res.sendFile(path.join(__dirname + "/views/home.html"));
});

app.get("/about", function(req,res)
{
  res.sendFile(path.join(__dirname + "/views/about.html"));
});

app.get("/employees", (req, res) =>
{
  if(req.query.status == 'Full Time' || req.query.status == 'Part Time')
  {
    dataService.getEmployeesByStatus(req.query.status).then((data) =>
    {
      res.json(data);
    }).catch(()=>
    {
      res.json({message: 'No result returned'});
    });
  }
  else if(req.query.manager)
  {
    dataService.getEmployeesByManager(req.query.manager).then((data) =>
    {
      res.json(data);
    }).catch(()=>{
      res.json({message: 'No result returned'});
    }); 
  }
  else if(req.query.department)
  {
    dataService.getEmployeesByDepartment(req.query.department).then((data) =>
    {
      res.json(data);
    }).catch(()=> 
    {
      res.json({message: 'No data returned'});
    });   
  }
  else
  {
    dataService.getAllEmployees().then((data) =>
    {	
     	res.json(data);
    }).catch(()=> 
    {
      res.json({message: 'No data returned'});
    });
  }
});

app.get("/employee/:empNum", (req,res) => 
{
  dataService.getEmployeeByNum(req.params.empNum).then((data) =>
  {
    res.json(data);
  }).catch(()=> 
  {
    res.json({message: 'No data returned'});
  });
});

app.get("/managers", (req,res) => 
{
  dataService.getManagers().then((data) =>
  {
    res.json(data);
  }).catch(()=>
  {
    res.json({message: 'No data returned'});
  });
});

app.get("/departments", (req,res) => 
{
  dataService.getDepartments().then((data) =>
  {
    res.json(data);
  }).catch(()=> 
  {
    res.json({message: 'No data returned'});
  });
});

//Page Not found
app.use((req, res) =>
{
  res.status(404).send("Page Not Found");
});
dataService.initialize().then(() =>
{
  app.listen(HTTP_PORT, onHttpStart);
}).catch(() =>
{ 
  console.log('No data returned');
});
